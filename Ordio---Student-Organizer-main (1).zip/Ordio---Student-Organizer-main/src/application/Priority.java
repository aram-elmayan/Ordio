package application;

public enum Priority {
	High,
	Medium,
	Low;
}
